# Training & Trading Logic Review

**Date:** February 14, 2026  
**Branch:** update-1.1-mfe-mae-tracking-v2  
**Bot Status:** Running (Markets Closed)  
**Current Position:** LONG @ 5045.21 (MAE 2.05 points)

---

## Executive Summary

Comprehensive review identified **7 critical issues** and **3 optimization opportunities** in training logic, parameter configuration, and trading execution. Most critical: **Stop loss is 3.3x wider than intended** due to timeframe scaling conflict.

### Priority Issues (P0)

1. **🔴 CRITICAL: Stop Loss Misconfiguration**
   - **Expected:** 0.12% SL for M1 (scaled from 0.40% base)
   - **Actual:** 0.40% SL (unscaled M5/M15 value)
   - **Impact:** 3.3x wider stop loss = excessive risk per trade
   - **Root Cause:** Learned parameters not scaled for M1 timeframe

2. **🟡 HIGH: Asymmetric Parameter Updates**
   - **TP:** 40 updates (0.60% → 0.8521%) ✅
   - **SL:** 0 updates (stuck at 0.40%) ❌
   - **Impact:** Risk/reward ratio degrading over time

3. **🟠 MEDIUM: Excessive Exploration Rate**
   - **Epsilon:** 0.8534 (85% random actions)
   - **Training Steps:** 831 trigger / 869 harvester
   - **Impact:** Barely exploiting learned knowledge

---

## 1. Parameter Configuration Analysis

### 1.1 Timeframe Scaling System

**Design Intent:**
```python
# harvester_agent.py:588-592
def _get_timeframe_scale(self) -> float:
    tf_map = {"M1": 0.3, "M5": 0.6, "M15": 1.0, "M30": 1.5, "H1": 2.0, "H4": 3.5, "D1": 5.0}
    return tf_map.get(self.timeframe, 1.0)
```

**Scaling Logic:**
- M1: 0.3x (tighter stops, faster exits)
- M5: 0.6x
- M15: 1.0x (baseline)
- H1+: 2.0x+ (wider stops, patience)

**Philosophy:** Lower timeframes need tighter risk management due to noise and faster price action.

### 1.2 Actual Parameter Values

**From `learned_parameters.json`:**
```json
{
  "XAUUSD_M5_default": {
    "harvester_profit_target_pct": {"value": 0.6000, "update_count": 0},
    "harvester_stop_loss_pct": {"value": 0.4000, "update_count": 0}
  },
  "XAUUSD_M1_default": {
    "harvester_profit_target_pct": {"value": 0.8521, "update_count": 40},
    "harvester_stop_loss_pct": {"value": 0.4000, "update_count": 0}
  }
}
```

**From Bot Logs:**
```
[HARVESTER] Exit plan: TP=0.60% SL=0.40% soft=200 bars hard=400 bars 
min_profit=0.20% (timeframe=M1 scale=0.30)
```

### 1.3 The Conflict

**Expected Behavior (Code Intent):**
```python
# harvester_agent.py:567
self.stop_loss_pct = self._get_param(
    "harvester_stop_loss_pct", 
    STOP_LOSS_PCT_DEFAULT * timeframe_scale  # 0.40% * 0.3 = 0.12%
)
```

**Actual Behavior:**
1. Code calculates default: `0.40% * 0.3 = 0.12%`
2. Calls `_get_param("harvester_stop_loss_pct", 0.12%)`
3. LearnedParametersManager returns: `0.40%` (from file)
4. **Result:** Bot uses 0.40% SL instead of 0.12%

**Why This Happens:**
- `InstrumentParameters.get()` returns the stored value if it exists
- Stored value (0.40%) was created for M5/M15 without scaling
- Default value (0.12%) is **never used** because parameter exists

### 1.4 Impact Analysis

**Risk Per Trade (Current):**
- Entry: $5045.21
- SL @ 0.40%: $5045.21 * 0.004 = **$20.18 loss**
- SL @ 0.12%: $5045.21 * 0.0012 = **$6.05 loss**
- **Excess Risk:** 233% (>3x intended)

**Historical Impact:**
- Previous underwater position had MAE = 164.64 points (2.78%)
- At 0.40% SL: Would have triggered at 0.40% = **FAIL** (didn't trigger)
- At 0.12% SL: Would have triggered at 0.12% = **SUCCESS** (earlier exit)
- **Conclusion:** Emergency SL fix at 0.12% was correct, but learned SL at 0.40% creates confusion

**Current Position:**
- LONG @ 5045.21
- MAE: 2.05 points (0.04%)
- Within both 0.12% and 0.40% thresholds ✅
- No immediate danger, but future risk elevated

---

## 2. Training Progress Analysis

### 2.1 Training Metadata

**From `training_metadata.json`:**
```json
{
  "trigger_training_steps": 831,
  "trigger_epsilon": 0.8533891362999211,
  "harvester_training_steps": 869,
  "trigger_platt_a": 0.975,
  "trigger_platt_b": -0.0025
}
```

### 2.2 Exploration Schedule

**Environment Configuration:**
```bash
EPSILON_START=1.0
EPSILON_END=0.1
EPSILON_DECAY=0.9995
FORCE_EXPLORATION=1
MAX_BARS_INACTIVE=10
```

**Current State:**
- **Epsilon:** 0.8534 (85.34% exploration)
- **Decay Rate:** 0.9995 per step
- **Steps to reach ε=0.5:** ~1386 steps (555 more needed)
- **Steps to reach ε=0.1:** ~4600 steps (3769 more needed)

**Epsilon Decay Formula:**
```
ε(t) = max(ε_end, ε_start * decay^t)
0.8534 = 1.0 * 0.9995^831
```

### 2.3 Exploration vs Exploitation Trade-off

**Current Behavior:**
- **85.3% of actions:** Random (LONG or SHORT with 50/50 chance)
- **14.7% of actions:** Model-based (Q-value argmax)
- **Every 10 bars:** Forced entry if no trade taken

**Expected Behavior at This Stage:**
- With 831 training steps, ε ≈ 0.85 is **correct** per schedule
- But schedule is **too slow** for meaningful learning
- At 1 trade every 10 bars, reaching ε=0.1 takes ~46,000 bars (32+ days on M1!)

**Learning Progress:**
- Training steps: 869 (harvester) / 831 (trigger)
- Buffer capacity: 50,000 experiences
- Min buffer size: 100 experiences
- **Status:** Well past minimum, actively training ✅

### 2.4 Forced Exploration Issue

**Code Logic (trigger_agent.py:315-327):**
```python
# Forced exploration after too many bars flat
if self.force_exploration and self.bars_since_trade >= self.max_bars_inactive:
    action = random.choice([1, 2])  # Force LONG or SHORT
    LOG.info("[TRIGGER] FORCED ENTRY after %d bars flat: action=%d", 
             self.bars_since_trade, action)
    self.bars_since_trade = 0
    return action, 0.5, PREDICTED_RUNWAY_FALLBACK
```

**Impact:**
- **Every 10 bars (~10 minutes on M1):** Forced trade regardless of setup
- Creates **artificial trade frequency**
- Reduces signal quality (random entries don't learn market patterns)
- Useful for: Preventing "always NO_ENTRY" collapse
- Harmful for: Learning quality entries (noise dominates)

**Recommendation:**
- Keep FORCE_EXPLORATION=1 until ε < 0.3
- Then disable to learn quality over quantity
- Or increase MAX_BARS_INACTIVE to 50-100 bars

---

## 3. Parameter Update Logic Analysis

### 3.1 Harvester Parameter Updates

**From `harvester_agent.py:680-735`:**
```python
def _update_exit_thresholds(self, capture_ratio: float, was_wtl: bool):
    """Update profit target (TP) based on trade outcome."""
    
    # === Profit target adjustment ===
    if was_wtl:
        profit_gradient = -0.15  # Reduce TP
    elif capture_ratio > 0.7:
        profit_gradient = -0.06  # Tighten TP
    elif capture_ratio < 0.3:
        profit_gradient = 0.10   # Widen TP
    else:
        profit_gradient = (0.5 - capture_ratio) * 0.15
    
    # Update profit target parameter
    new_tp = self.param_manager.update(
        self.symbol, "harvester_profit_target_pct", 
        profit_gradient, timeframe=self.timeframe, broker=self.broker
    )
    
    # Update local cached value WITH SCALING
    self.profit_target_pct = new_tp * self._get_timeframe_scale()
    
    # === Stop loss adjustment ===
    # ❌ NOT IMPLEMENTED!
```

**Key Findings:**

1. **TP Updates:** ✅ Implemented
   - Adjusts based on capture ratio
   - 40 updates recorded (0.60% → 0.8521%)
   - **BUG:** Updates WITHOUT scaling, then scales on load
   - Result: M1 TP = 0.8521% (from updates) but should be scaled?

2. **SL Updates:** ❌ NOT IMPLEMENTED  
   - No gradient calculation for stop loss
   - No call to `param_manager.update("harvester_stop_loss_pct", ...)`
   - Result: SL frozen at initial value (0.40%)

3. **Scaling Inconsistency:**
   - Line 711: `self.profit_target_pct = new_tp * self._get_timeframe_scale()`
   - But saved value is `new_tp` (unscaled)
   - Next load: Gets `new_tp` then scales again?
   - **Result:** Double scaling on next restart!

### 3.2 Parameter Update Flow

**Save Process:**
```
1. Trade completes with capture_ratio + was_wtl
2. Calculate profit_gradient
3. Call param_manager.update() → returns new_tp (absolute value)
4. Apply timeframe scale: self.profit_target_pct = new_tp * scale
5. Save to disk: writes new_tp (unscaled)
```

**Load Process:**
```
1. Load from disk: reads new_tp (unscaled)
2. Apply timeframe scale: self.profit_target_pct = new_tp * scale
3. Result: scale applied every time
```

**Verdict:** Actually correct! The value is stored unscaled, then scaled on load.

### 3.3 Why SL Never Updates

**Missing Implementation:**
- No SL adjustment logic in `_update_exit_thresholds()`
- No gradient calculation based on:
  - How often SL triggered?
  - Average MAE before exit?
  - Premature SL exits (small MFE)?
- No call to `param_manager.update("harvester_stop_loss_pct", ...)`

**Proposed SL Update Logic:**
```python
# === Stop loss adjustment ===
if was_wtl:
    # WTL: SL was too wide (let winner become loser)
    sl_gradient = -0.10  # Tighten SL by ~10%
elif sl_triggered:
    # Check if SL exit was premature (had significant MFE before MAE hit SL)
    if mfe_pct > self.stop_loss_pct * 1.5:
        # Premature SL: widen slightly
        sl_gradient = 0.05
    else:
        # Appropriate SL: no change
        sl_gradient = 0.0
else:
    sl_gradient = 0.0  # No SL trigger, no update

if sl_gradient != 0.0:
    new_sl = self.param_manager.update(
        self.symbol, "harvester_stop_loss_pct", 
        sl_gradient, timeframe=self.timeframe, broker=self.broker
    )
    self.stop_loss_pct = new_sl * self._get_timeframe_scale()
```

---

## 4. Trading Decision Flow Analysis

### 4.1 Entry Logic (Trigger Agent)

**Decision Tree:**
```
1. Check if in position → NO_ENTRY if yes
2. Epsilon-greedy exploration check:
   - If rand() < ε (0.8534) → RANDOM action (LONG/SHORT)
   - If bars_since_trade >= 10 → FORCED ENTRY
3. Feasibility gate (disabled in paper mode)
4. Model inference:
   - DDQN (if trained) → Q-values → argmax
   - Fallback (MA crossover) → direction signal
5. Confidence floor gate (disabled in paper mode)
6. Economics breakeven gate (disabled in paper mode)
7. Decay epsilon
8. Return: (action, confidence, predicted_runway)
```

**Gating Status (Paper Mode):**
- ✅ **Epsilon Exploration:** Active (85%)
- ✅ **Forced Exploration:** Active (every 10 bars)
- ❌ **Feasibility Gate:** Disabled
- ❌ **Confidence Floor:** Disabled
- ❌ **Economics Breakeven:** Disabled

**Result:** Pure exploration mode - learning reward function, not exploiting

### 4.2 Exit Logic (Harvester Agent)

**Decision Tree:**
```
1. Emergency Stop Loss Check (ALWAYS EXECUTED):
   - If MAE% >= SL% → IMMEDIATE CLOSE
   - Bypasses model, executes before any logic
2. Model inference:
   - DDQN (if trained) → Q-values → argmax (HOLD=0, CLOSE=1)
   - Fallback strategy → rule-based exit
3. Fallback checks (if no model):
   a. Hard stop loss: MAE% >= SL% → CLOSE
   b. Profit target: MFE% >= TP% → CLOSE
   c. Soft time stop: ticks_held > soft_limit AND profit > min → CLOSE
   d. Hard time stop: ticks_held > hard_limit → CLOSE
   e. Capture decay: MFE drops significantly → CLOSE
4. Return: (action, confidence)
```

**Critical Paths:**
- **Emergency SL:** Line 226-243 (always executes, uses self.stop_loss_pct)
- **Fallback SL:** Line 380 (in _fallback_strategy, also uses self.stop_loss_pct)
- **Both use same value:** Currently 0.40% (should be 0.12%)

**No Exploration in Harvester:**
- Harvester doesn't implement epsilon-greedy
- Always exploits (uses model or fallback rules)
- Could limit learning if model gets stuck in local optimum
- Trade-off: Safety (rule-based exits) vs Learning (exploration)

### 4.3 Reward Shaping

**Trigger Agent Reward (runway utilization):**
```python
# src/agents/trigger_agent.py (reward calculation)
runway_utilization = actual_mfe / predicted_runway
entry_quality_bonus = 1.0 if actual_mfe > min_threshold else 0.0
false_signal_penalty = -1.0 if actual_mfe < min_threshold else 0.0
reward = runway_utilization + entry_quality_bonus + false_signal_penalty
```

**Harvester Agent Reward (capture efficiency):**
```python
# src/agents/harvester_agent.py:802-850
capture_ratio = exit_pnl / mfe  # How much of MFE was captured
wtl_penalty = -3.0 if was_wtl else 0.0  # Winner-to-loser penalty
timing_bonus = 0.5 if early_exit_with_good_capture else 0.0
reward = capture_ratio + wtl_penalty + timing_bonus
```

**Assessment:**
- ✅ Rewards align with stated goals (runway, capture, avoid WTL)
- ✅ Scaled to encourage/discourage behaviors
- ⚠️ No explicit friction cost in harvester reward
- ⚠️ Timing bonus could encourage premature exits

---

## 5. Risk Management Integration

### 5.1 VaR-Based Position Sizing

**From `ctrader_ddqn_paper.py`:**
```python
# Position sizing from VaR estimation
var_95 = var_estimator.get(95)
from src.risk.var_estimator import position_size_from_var
quantity = position_size_from_var(
    equity=10000,           # Paper trading equity
    var_pct=var_95,         # Value at Risk (95%)
    symbol=symbol,
    var_multiplier=1.0,     # From learned params
    base_qty=0.01           # Configured base
)
```

**Status:**
- ✅ VaR calculated from rolling window
- ✅ Position size adjusted for risk
- ❌ Not integrated with learned parameters (should be!)
- ❌ Hardcoded equity (should read from account)

### 5.2 Circuit Breakers

**Active Breakers:**
- Daily loss limit
- Consecutive loss limit  
- Drawdown limit
- Single trade loss limit

**Status:**
- ✅ Implemented
- ✅ Persisted to `circuit_breakers.json`
- ⚠️ Not visible in decision logs
- ⚠️ Unclear if breakers actually halt trading or just warn

### 5.3 Friction Cost Awareness

**From `harvester_agent.py:590-610`:**
```python
def get_friction_cost_pct(self, entry_price: float, quantity: float) -> float:
    """Calculate friction costs as % of entry price."""
    if not self.friction_calculator:
        return 0.0
    
    total_friction = self.friction_calculator.calculate_total_cost(
        symbol=self.symbol,
        side="BUY",  # Friction symmetric for BUY/SELL
        quantity=quantity,
        price=entry_price
    )
    
    return (total_friction / entry_price) * 100.0
```

**Usage:**
- ✅ Calculated at entry (trigger agent)
- ✅ Subtracted from predicted runway
- ❌ NOT used in harvester exit decisions
- ❌ NOT factored into TP/SL thresholds

**Expected:**
- TP should be: `base_tp + friction + minimum_profit`
- SL should account for friction asymmetry (entry friction already paid)
- Currently: TP/SL are friction-unaware (could exit at breakeven-friction)

---

## 6. Conflict Summary

### 6.1 Critical Conflicts

| # | Conflict | Severity | Impact | Status |
|---|----------|----------|--------|--------|
| 1 | **SL Timeframe Scaling** | 🔴 CRITICAL | Stop loss 3.3x wider than designed | ACTIVE |
| 2 | **Asymmetric Parameter Updates** | 🟡 HIGH | TP adapts, SL frozen | ACTIVE |
| 3 | **Excessive Exploration** | 🟠 MEDIUM | 85% random trades, slow learning | ACTIVE |
| 4 | **Forced Entry Frequency** | 🟠 MEDIUM | Trade every 10 bars regardless of setup | ACTIVE |
| 5 | **No Harvester Exploration** | 🟢 LOW | Exit strategy can't explore alternatives | BY DESIGN |
| 6 | **Friction Not in Harvester** | 🟡 HIGH | Exits don't account for costs | ACTIVE |
| 7 | **TP/SL Unscaled Storage** | ℹ️ INFO | Confusing but functionally correct | CLARIFIED |

### 6.2 Design Inconsistencies

| Component | Intended Behavior | Actual Behavior | Aligned? |
|-----------|------------------|-----------------|----------|
| M1 Stop Loss | 0.12% (scaled) | 0.40% (unscaled) | ❌ NO |
| M1 Profit Target | 0.18% (scaled) | 0.8521% (learned) | ⚠️ PARTIAL |
| Trigger Exploration | ε-greedy + forced | ε-greedy + forced | ✅ YES |
| Harvester Exploration | None (safety first) | None | ✅ YES |
| Parameter Learning | Both TP and SL | Only TP | ❌ NO |
| Friction Awareness | Entry + Exit | Entry only | ⚠️ PARTIAL |

### 6.3 Environment Variable Conflicts

**Active Settings:**
```bash
TIMEFRAME_MINUTES=1          # M1 bars
PAPER_MODE=1                 # Training mode
DISABLE_GATES=1              # No confidence/feasibility gates
EPSILON_START=1.0            # 100% exploration initially
EPSILON_DECAY=0.9995         # Very slow decay
FORCE_EXPLORATION=1          # Force trade every 10 bars
MAX_BARS_INACTIVE=10         # Low threshold
DDQN_ONLINE_LEARNING=1       # Enable training
```

**Conflicts:**
- `PAPER_MODE=1` + epsilon-greedy is **correct** for training
- `DISABLE_GATES=1` + high epsilon = **extreme exploration** (appropriate early training)
- `FORCE_EXPLORATION=1` + `MAX_BARS_INACTIVE=10` = **too aggressive** (could increase to 50-100)
- `EPSILON_DECAY=0.9995` is **very slow** (designed for long-term learning, OK)

### 6.4 Training vs Production Mismatch

**Current Mode:** Paper Trading (Training)

**Production Checklist:**
- [ ] Disable FORCE_EXPLORATION
- [ ] Set EPSILON to low value (0.05-0.1)
- [ ] Enable gates (DISABLE_GATES=0)
- [ ] Set confidence floor (0.55-0.65)
- [ ] Set feasibility threshold (0.5-0.7)
- [ ] **FIX SL SCALING FIRST!**
- [ ] Verify friction awareness in exits
- [ ] Test with small position sizes

---

## 7. Recommendations

### 7.1 Immediate Fixes (P0) - Do Now

**1. Fix Stop Loss Scaling (CRITICAL)**

Two options:

**Option A: Reset M1 Parameters (Clean Slate)**
```bash
# Backup current parameters
cp data/learned_parameters.json data/learned_parameters.json.backup

# Edit learned_parameters.json - for XAUUSD_M1_default:
# - Delete harvester_stop_loss_pct (let code use scaled default)
# - OR set value to 0.12 explicitly

# Restart bot - will use 0.12% SL
```

**Option B: Add Manual SL Scaling (Code Fix)**
```python
# In harvester_agent.py:567, force scaling:
base_sl = self._get_param("harvester_stop_loss_pct", STOP_LOSS_PCT_DEFAULT)
self.stop_loss_pct = base_sl * self._get_timeframe_scale()

# This scales the learned value on every load
# Downside: If SL was learned for M1, it gets over-scaled
```

**Recommendation:** **Option A** - Reset to clean scaled defaults for M1.

**2. Implement Stop Loss Learning**

Add to `harvester_agent.py:_update_exit_thresholds()`:
```python
# === Stop loss adjustment ===
if was_wtl and mfe_pct > self.stop_loss_pct * 2:
    # WTL with significant MFE → SL too wide
    sl_gradient = -0.08  # Tighten by 8%
    LOG.info("[HARVESTER] WTL with MFE=%.2f%% → tightening SL", mfe_pct)
elif was_wtl and mfe_pct < self.stop_loss_pct * 0.5:
    # WTL with small MFE → SL might be OK, entry was bad
    sl_gradient = 0.0
    LOG.info("[HARVESTER] WTL with small MFE=%.2f%% → SL unchanged", mfe_pct)
else:
    sl_gradient = 0.0

if sl_gradient != 0.0:
    new_sl = self.param_manager.update(
        self.symbol, "harvester_stop_loss_pct",
        sl_gradient, timeframe=self.timeframe, broker=self.broker
    )
    # Don't scale here - scaling happens on next load
    LOG.info("[HARVESTER] Updated SL: %.4f%% (gradient=%.3f)", new_sl, sl_gradient)
```

**3. Add Friction to Harvester Exits**

Modify fallback TP check:
```python
# harvester_agent.py:_fallback_strategy()
# Current:
if mfe_pct >= self.profit_target_pct:
    return True  # CLOSE

# Proposed:
friction_pct = self.get_friction_cost_pct(entry_price, position_qty)
net_profit = mfe_pct - friction_pct  # Subtract entry + exit friction
if net_profit >= self.profit_target_pct:
    LOG.info("[HARVESTER] TP hit: net_profit=%.2f%% >= %.2f%%", net_profit, self.profit_target_pct)
    return True
```

### 7.2 Training Optimizations (P1) - Next Sprint

**1. Adjust Exploration Schedule**

Current schedule reaches ε=0.1 after ~4600 steps (32 days at current pace).

Options:
- **Faster decay:** `EPSILON_DECAY=0.999` (reaches ε=0.1 in ~2300 steps)
- **Lower end:** `EPSILON_END=0.05` (more exploitation once trained)
- **Adaptive:** Accelerate decay once capture ratio improves

**2. Reduce Forced Exploration**

```bash
# Current:
MAX_BARS_INACTIVE=10  # Every 10 bars

# Proposed:
MAX_BARS_INACTIVE=50  # Every 50 bars (less noise)
# OR disable after ε < 0.3:
# if epsilon < 0.3:
#     FORCE_EXPLORATION=0
```

**3. Add Harvester Exploration (Optional)**

Currently harvester has no randomness. Consider:
```python
# In harvester_agent.py:decide()
if self.enable_training and random.random() < epsilon_harvester:
    action = random.choice([0, 1])  # HOLD or CLOSE
    LOG.debug("[HARVESTER] Explore: random action=%d", action)
    return action, 0.5

# Use separate epsilon schedule (slower decay)
```

Pros: Can discover novel exit strategies  
Cons: Safety risk (random exits could close good trades early)

### 7.3 Production Readiness (P2) - Before Live Trading

**Checklist:**

1. **Verify SL/TP Values:**
   - [ ] M1 SL = 0.12% ± learned adjustments
   - [ ] M1 TP = 0.18% ± learned adjustments
   - [ ] Asymmetry makes sense (TP > SL for positive expectancy)

2. **Enable Gating:**
   - [ ] `DISABLE_GATES=0`
   - [ ] `FEAS_THRESHOLD=0.5` (from learned params ideally)
   - [ ] `CONFIDENCE_FLOOR=0.55` (from learned params)
   - [ ] Economics breakeven gate active

3. **Reduce Exploration:**
   - [ ] `EPSILON_START=0.1` (or current epsilon if < 0.1)
   - [ ] `FORCE_EXPLORATION=0` (disable forced entries)
   - [ ] Epsilon should be 0.05-0.1 in production

4. **Verify Risk Limits:**
   - [ ] Circuit breakers configured appropriately
   - [ ] Max position size reasonable for account
   - [ ] SL distance acceptable for volatility regime

5. **Testing:**
   - [ ] Run 24h with PAPER_MODE=1, gates enabled, low epsilon
   - [ ] Verify SL triggers correctly at 0.12%
   - [ ] Check capture ratios, WTL frequency
   - [ ] Confirm friction costs reflected in exits

6. **Monitoring:**
   - [ ] Log analysis automation
   - [ ] Alert on circuit breaker triggers
   - [ ] Track learned parameter evolution
   - [ ] MFE/MAE distribution analysis

### 7.4 Long-Term Enhancements (P3)

1. **Multi-Timeframe Training:**
   - Train separate models for M1 vs M5 vs M15
   - Compare performance, select best per market regime
   - Cross-timeframe ensemble

2. **Regime-Aware Parameters:**
   - Detect trending vs mean-reverting regimes
   - Adjust TP/SL accordingly (wider in trends, tighter in range)
   - Already partially implemented via RegimeDetector

3. **Meta-Learning:**
   - Learn learning rates (how fast to adapt TP/SL)
   - Learn exploration schedule (epsilon decay)
   - Learn when to trust model vs fallback

4. **Friction-Optimal Exits:**
   - Model slippage as function of size + volatility
   - Optimize exit timing to minimize spread impact
   - Account for time-of-day liquidity patterns

---

## 8. Test Plan

### 8.1 Unit Tests

**Test: Stop Loss Scaling**
```python
def test_harvester_sl_scaling_m1():
    """Verify M1 uses 0.12% SL (scaled from 0.40% base)."""
    harvester = HarvesterAgent(
        timeframe="M1",
        param_manager=None  # No learned params
    )
    assert harvester.stop_loss_pct == 0.12, \
        f "Expected 0.12% SL for M1, got {harvester.stop_loss_pct}%"

def test_harvester_sl_scaling_m15():
    """Verify M15 uses 0.40% SL (unscaled baseline)."""
    harvester = HarvesterAgent(
        timeframe="M15",
        param_manager=None
    )
    assert harvester.stop_loss_pct == 0.40, \
        f "Expected 0.40% SL for M15, got {harvester.stop_loss_pct}%"
```

**Test: Parameter Updates**
```python
def test_harvester_tp_sl_updates():
    """Verify both TP and SL update after trades."""
    harvester = HarvesterAgent(
        enable_training=True,
        param_manager=mock_param_manager
    )
    
    initial_tp = harvester.profit_target_pct
    initial_sl = harvester.stop_loss_pct
    
    # Simulate WTL trade
    harvester._update_exit_thresholds(capture_ratio=0.2, was_wtl=True)
    
    assert harvester.profit_target_pct < initial_tp, "TP should decrease after WTL"
    assert harvester.stop_loss_pct < initial_sl, "SL should tighten after WTL"
```

### 8.2 Integration Tests

**Test: Full Trade Lifecycle**
```python
def test_full_trade_with_correct_sl():
    """Run bot for 100 bars, verify SL triggers at 0.12% for M1."""
    bot = MockBot(timeframe="M1", paper_mode=True)
    
    # Open LONG at 5000.00
    bot.simulate_entry(direction=1, price=5000.00)
    
    # Drop price to trigger 0.12% SL
    sl_price = 5000.00 * (1 - 0.0012)  # 4994.00
    bot.simulate_price_move(sl_price - 0.01)
    
    # Verify exit occurred
    assert bot.position == 0, "Position should be closed"
    assert bot.last_exit_reason == "STOP_LOSS", "Should exit via SL"
```

### 8.3 Validation Tests (Dry Run)

**Test Plan:**
1. Reset M1 SL to 0.12% (delete from learned params)
2. Run bot for 24 hours with PAPER_MODE=1
3. Verify:
   - All exits at 0.12% SL execute
   - No exits at 0.40% SL execute
   - TP hits correctly (current 0.8521% for M1)
   - Friction costs subtracted from PnL
4. Check logs for:
   - "[HARVESTER] Exit plan: ... SL=0.12% ... (timeframe=M1 scale=0.30)"
   - "[HARVESTER_EMERGENCY_SL] Stop loss TRIGGERED: MAE=X.XX% >= SL=0.12%"
5. Analyze results:
   - Capture ratio distribution
   - WTL frequency
   - Average trade duration
   - Parameter update frequency

---

## 9. Conclusion

### 9.1 Summary of Findings

**Critical Issues:** 3
- SL 3.3x wider than designed
- SL never learns/adapts
- Friction not in harvester exits

**High Priority:** 2
- Excessive exploration (85%)
- Forced entries too frequent

**Medium Priority:** 1
- No harvester exploration (by design, but limits learning)

### 9.2 Immediate Action Items

1. **TODAY:** Fix SL scaling (reset M1 params)
2. **THIS WEEK:** Implement SL learning + friction in exits
3. **BEFORE LIVE:** Complete production readiness checklist

### 9.3 Expected Impact

**After Fixes:**
- **Risk per trade:** Reduced by 67% (0.40% → 0.12% SL)
- **Parameter adaptation:** SL will evolve with TP (symmetric learning)
- **Exit quality:** Friction-aware exits prevent breakeven-loss trades
- **Exploration efficiency:** Better signal-to-noise in training

**Metrics to Track:**
- Capture ratio (target: 50-70%)
- WTL frequency (target: <15%)
- Sharpe ratio (target: >1.5 after 100 trades)
- SL trigger rate (expect higher initially at 0.12% vs 0.40%)

---

**Prepared by:** GitHub Copilot  
**Review Status:** Complete  
**Next Review:** After implementing P0 fixes
